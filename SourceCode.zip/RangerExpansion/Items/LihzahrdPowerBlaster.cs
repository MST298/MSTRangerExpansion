using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace RangerExpansion.Items
{
	public class LihzahrdPowerBlaster : ModItem
	{
		public override void SetDefaults()
		{
			item.crit = 6;
			item.damage = 24;
			item.ranged = true;
			item.width = 38;
			item.scale = 1f;
			item.maxStack = 1;
			item.height = 38;
			item.useTime = 6;
			item.useAnimation = 6;
			item.useStyle = 5;
			item.knockBack = 6.4f;
			item.value = 650000;
			item.rare = 8;
			item.UseSound = SoundID.Item12;
			item.shoot = mod.ProjectileType("MiniLaser");
			item.useAmmo = ModContent.ItemType<PowerCell>();
			item.shootSpeed = 10f;
			item.autoReuse = true;
			item.noMelee = true;
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.LihzahrdPowerCell, 2);
			recipe.AddIngredient(ItemID.SolarTablet, 1);
			recipe.AddIngredient(mod, "LightBlaster", 1);
			recipe.AddTile(TileID.MythrilAnvil);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
		public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
		{
			float numberProjectiles = 2;
			float rotation = MathHelper.ToRadians(20);
			position += Vector2.Normalize(new Vector2(speedX, speedY)) * 20f;
			for (int i = 0; i < numberProjectiles; i++)
			{
				Vector2 pertubedSpeed = new Vector2(speedX, speedY).RotatedByRandom(MathHelper.ToRadians(4));
				Projectile.NewProjectile(position.X, position.Y, pertubedSpeed.X, pertubedSpeed.Y, type, damage, knockBack, player.whoAmI);
			}
			return false;
		}
		public override Vector2? HoldoutOffset()
		{
			return new Vector2(-2, 0);
		}
	}
}