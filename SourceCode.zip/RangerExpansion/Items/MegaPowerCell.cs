using Terraria.ID;
using Terraria.ModLoader;

namespace RangerExpansion.Items
{
    public class MegaPowerCell : ModItem
    {
        public override void SetDefaults()
        {
            item.damage = 24;
            item.ranged = true;
            item.width = 8;
            item.height = 8;
            item.maxStack = 999;
            item.consumable = true;
            item.knockBack = 0.5f;
            item.value = 10;
            item.rare = 2;
            item.shoot = mod.ProjectileType("MegaLaser");
            item.shootSpeed = 6f;
            item.ammo = mod.ItemType("PowerCell");
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(mod, "PowerCell", 150);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this, 50);
            recipe.AddRecipe();
        }
    }
}