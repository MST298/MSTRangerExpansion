using Terraria.ID;
using Terraria.ModLoader;

namespace RangerExpansion.Items
{
    public class CursedPowerCell : ModItem
    {
        public override void SetDefaults()
        {
            item.damage = 9;
            item.ranged = true;
            item.width = 8;
            item.height = 8;
            item.maxStack = 999;
            item.consumable = true;
            item.knockBack = 0.5f;
            item.value = 75;
            item.rare = 2;
            item.shoot = mod.ProjectileType("CursedLaser");
            item.shootSpeed = 14f;
            item.ammo = mod.ItemType("PowerCell");
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(mod, "PowerCell", 150);
            recipe.AddIngredient(ItemID.CursedFlame, 2);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this, 150);
            recipe.AddRecipe();
        }
    }
}