using Terraria.ID;
using Terraria.ModLoader;

namespace RangerExpansion.Items
{
    public class PowerCell : ModItem
    {
        public override void SetDefaults()
        {
            item.damage = 6;
            item.ranged = true;
            item.width = 8;
            item.height = 8;
            item.maxStack = 999;
            item.consumable = true;
            item.knockBack = 0.5f;
            item.value = 10;
            item.rare = 2;
            item.shoot = mod.ProjectileType("MiniLaser");
            item.shootSpeed = 14f;
            item.ammo = item.type;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.CopperOre, 2);
            recipe.AddIngredient(ItemID.IronOre, 2);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this, 150);
            recipe.AddRecipe();

            ModRecipe recipe2 = new ModRecipe(mod);
            recipe2.AddIngredient(ItemID.CopperOre, 2);
            recipe2.AddIngredient(ItemID.LeadOre, 2);
            recipe2.AddTile(TileID.Anvils);
            recipe2.SetResult(this, 150);
            recipe2.AddRecipe();

            ModRecipe recipe3 = new ModRecipe(mod);
            recipe3.AddIngredient(ItemID.TinOre, 2);
            recipe3.AddIngredient(ItemID.IronOre, 2);
            recipe3.AddTile(TileID.Anvils);
            recipe3.SetResult(this, 150);
            recipe3.AddRecipe();

            ModRecipe recipe4 = new ModRecipe(mod);
            recipe4.AddIngredient(ItemID.TinOre, 2);
            recipe4.AddIngredient(ItemID.LeadOre, 2);
            recipe4.AddTile(TileID.Anvils);
            recipe4.SetResult(this, 150);
            recipe4.AddRecipe();
        }
    }
}