using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace RangerExpansion.Items
{
	public class EnergyShotgun : ModItem
	{

		public override void SetDefaults() 
		{
			item.crit = 0;
			item.damage = 30;
			item.ranged = true;
			item.width = 38;
			item.scale = 1.2f;
			item.maxStack = 1;
			item.height = 38;
			item.useTime = 22;
			item.useAnimation = 22;
			item.useStyle = 5;
			item.knockBack = 2.4f;
			item.value = 250000;
			item.rare = 8;
			item.UseSound = SoundID.Item12;
			item.shoot = mod.ProjectileType("MiniLaser");
			item.useAmmo = ModContent.ItemType<PowerCell>();
			item.shootSpeed = 4f;
			item.autoReuse = true;
			item.noMelee = true;
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.Shotgun, 1);
			recipe.AddIngredient(ItemID.Wire, 35);
			recipe.AddIngredient(ItemID.TitaniumBar, 5);
			recipe.AddTile(TileID.MythrilAnvil);
			recipe.SetResult(this);
			recipe.AddRecipe();

			ModRecipe recipe2 = new ModRecipe(mod);
			recipe2.AddIngredient(ItemID.Shotgun, 1);
			recipe2.AddIngredient(ItemID.Wire, 35);
			recipe2.AddIngredient(ItemID.AdamantiteBar, 5);
			recipe2.AddTile(TileID.MythrilAnvil);
			recipe2.SetResult(this);
			recipe2.AddRecipe();
		}
		public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
		{
			float numberProjectiles = 3;
			float rotation = MathHelper.ToRadians(28);
			position += Vector2.Normalize(new Vector2(speedX, speedY)) * 28f;
			for (int i = 0; i < numberProjectiles; i++)
			{
				Vector2 pertubedSpeed = new Vector2(speedX, speedY).RotatedByRandom(MathHelper.ToRadians(28));
				Projectile.NewProjectile(position.X, position.Y, pertubedSpeed.X, pertubedSpeed.Y, type, damage, knockBack, player.whoAmI);
			}
			return false;
		}
		public override Vector2? HoldoutOffset()
		{
			return new Vector2(-4, -1);
		}
	}
}