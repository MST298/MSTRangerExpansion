using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace RangerExpansion.Items
{
	[AutoloadEquip(EquipType.Body)]
	public class NecroSuperChestplate : ModItem
	{
		public override void SetStaticDefaults() 
		{
			Tooltip.SetDefault("'Why is it super? Because it's made of beetles.'\n11% increased ranged damage & critical strike chance");
		}

		public override void SetDefaults()
		{
			item.width = 24;
			item.height = 32;
			item.value = 250000;
			item.rare = 9;
			item.defense = 26;
		}

		public override void UpdateEquip(Player player)
		{
			player.rangedDamage *= 1.11f; // 25% melee damage
			player.rangedCrit += 11;
		}

	public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.NecroBreastplate, 1);
			recipe.AddIngredient(ItemID.BeetleHusk, 18);
			recipe.AddTile(TileID.MythrilAnvil);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}