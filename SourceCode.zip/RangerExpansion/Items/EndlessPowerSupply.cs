using Terraria.ID;
using Terraria.ModLoader;

namespace RangerExpansion.Items
{
    public class EndlessPowerSupply : ModItem
    {
        public override void SetDefaults()
        {
            item.damage = 6;
            item.ranged = true;
            item.width = 8;
            item.height = 8;
            item.maxStack = 1;
            item.consumable = true;
            item.knockBack = 0.5f;
            item.value = 1000;
            item.rare = 2;
            item.shoot = mod.ProjectileType("MiniLaser");
            item.shootSpeed = 14f;
            item.ammo = mod.ItemType("PowerCell");
            item.consumable = false;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(mod, "PowerCell", 3996);
            recipe.AddTile(TileID.CrystalBall);
            recipe.SetResult(this, 1);
            recipe.AddRecipe();
        }
    }
}