using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace RangerExpansion.Items
{
	public class TacticalMusket : ModItem
	{
		public override void SetStaticDefaults()
		{
			Tooltip.SetDefault("'Good for starting a war!'");
		}

		public override void SetDefaults() 
		{
			item.damage = 75;
			item.ranged = true;
			item.width = 38;
			item.scale = 1f;
			item.maxStack = 1;
			item.height = 38;
			item.useTime = 27;
			item.useAnimation = 27;
			item.useStyle = 5;
			item.knockBack = 5.25f;
			item.value = 300000;
			item.rare = 8;
			item.crit = 11;
			item.UseSound = SoundID.Item11;
			item.shoot = mod.ProjectileType("MiniLaser");
			item.useAmmo = AmmoID.Bullet;
			item.shootSpeed = 9f;
			item.noMelee = true;
			item.autoReuse = true;
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.Musket, 1);
			recipe.AddIngredient(ItemID.TitaniumBar, 8);
			recipe.AddTile(TileID.MythrilAnvil);
			recipe.SetResult(this);
			recipe.AddRecipe();

			ModRecipe recipe2 = new ModRecipe(mod);
			recipe2.AddIngredient(ItemID.Musket, 1);
			recipe2.AddIngredient(ItemID.AdamantiteBar, 8);
			recipe2.AddTile(TileID.MythrilAnvil);
			recipe2.SetResult(this);
			recipe2.AddRecipe();
		}
		public override Vector2? HoldoutOffset()
		{
			return new Vector2(-4, 0);
		}
	}
}