using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace RangerExpansion.Items
{
	[AutoloadEquip(EquipType.Head)]
	public class NecroSuperHelmet : ModItem
	{
		public override void SetStaticDefaults() 
		{
			Tooltip.SetDefault("'Why is it super? Because it's made of bones.'\n12% increased ranged damage\n6% increased ranged critical strike chance");
		}

		public override void SetDefaults()
		{
			item.width = 24;
			item.height = 32;
			item.value = 250000;
			item.rare = 9;
			item.defense = 12;
		}

		public override void UpdateEquip(Player player)
		{
			player.rangedDamage *= 1.12f; // 25% melee damage
			player.rangedCrit += 6;
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.NecroHelmet, 1);
			recipe.AddIngredient(ItemID.BeetleHusk, 12);
			recipe.AddTile(TileID.MythrilAnvil);
			recipe.SetResult(this);
			recipe.AddRecipe();

			ModRecipe recipe2 = new ModRecipe(mod);
			recipe2.AddIngredient(ItemID.AncientNecroHelmet, 1);
			recipe2.AddIngredient(ItemID.BeetleHusk, 12);
			recipe2.AddTile(TileID.MythrilAnvil);
			recipe2.SetResult(this);
			recipe2.AddRecipe();
		}
		public override bool IsArmorSet(Item head, Item body, Item legs)
		{
			return body.type == ModContent.ItemType<NecroSuperChestplate>() && legs.type == ModContent.ItemType<NecroSuperLegs>();
		}
		public override void UpdateArmorSet(Player player)
		{
			player.setBonus = "Ridiculous health regen, but you lose all your defense...";
			player.lifeRegen += 22;
			player.statDefense -= 99999;
		}
	}
}