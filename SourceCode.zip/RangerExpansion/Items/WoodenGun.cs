using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace RangerExpansion.Items
{
	public class WoodenGun : ModItem
	{

		public override void SetDefaults()
		{
			item.damage = 9;
			item.ranged = true;
			item.width = 38;
			item.scale = 1.1f;
			item.maxStack = 1;
			item.height = 38;
			item.useTime = 25;
			item.useAnimation = 25;
			item.useStyle = 5;
			item.knockBack = 1f;
			item.value = 0;
			item.rare = 8;
			item.UseSound = SoundID.Item11;
			item.shoot = mod.ProjectileType("FlamingPellet");
			item.useAmmo = ModContent.ItemType<FlamingPellet>();
			item.shootSpeed = 5.5f;
			item.autoReuse = false;
			item.noMelee = true;
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.Wood, 12);
			recipe.AddIngredient(ItemID.Torch, 1);
			recipe.AddTile(TileID.WorkBenches);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}

		public override Vector2? HoldoutOffset()
		{
			return new Vector2(-4, -1);
		}
	}
}