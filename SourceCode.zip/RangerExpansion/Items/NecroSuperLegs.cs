using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace RangerExpansion.Items
{
	[AutoloadEquip(EquipType.Legs)]
	public class NecroSuperLegs : ModItem
	{
		public override void SetStaticDefaults() 
		{
			Tooltip.SetDefault("'Why is it super? Because it makes you purple.'\n6% increased ranged damage\n4% increased ranged critical strike chance\n25% increased movement speed");
		}

		public override void SetDefaults()
		{
			item.width = 24;
			item.height = 32;
			item.value = 250000;
			item.rare = 9;
			item.defense = 15;
		}

		public override void UpdateEquip(Player player)
		{
			player.rangedDamage *= 1.06f; // 25% melee damage
			player.rangedCrit += 4;
			player.moveSpeed += 0.25f;
		}

	public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.NecroGreaves, 1);
			recipe.AddIngredient(ItemID.BeetleHusk, 14);
			recipe.AddTile(TileID.MythrilAnvil);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}