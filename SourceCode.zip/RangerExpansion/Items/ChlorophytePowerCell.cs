using Terraria.ID;
using Terraria.ModLoader;

namespace RangerExpansion.Items
{
    public class ChlorophytePowerCell : ModItem
    {
        public override void SetDefaults()
        {
            item.damage = 6;
            item.ranged = true;
            item.width = 8;
            item.height = 8;
            item.maxStack = 999;
            item.consumable = true;
            item.knockBack = 0.5f;
            item.value = 10;
            item.rare = 2;
            item.shoot = mod.ProjectileType("ChlorophyteLaser");
            item.shootSpeed = 14f;
            item.ammo = mod.ItemType("PowerCell");
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(mod, "PowerCell", 150);
            recipe.AddIngredient(ItemID.ChlorophyteOre, 2);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this, 100);
            recipe.AddRecipe();
        }
    }
}