using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace RangerExpansion.Items
{
	public class SDLCG : ModItem
	{
		public override void SetStaticDefaults() 
		{
			// DisplayName.SetDefault("TestSword"); // By default, capitalization in classnames will add spaces to the display name. You can customize the display name here by uncommenting this line.
			Tooltip.SetDefault("66% chance to not consume ammo\n'Space Dolphin Laser Chain Gun... You keeping up with these names?'");
			DisplayName.SetDefault("S.D.L.C.G.");
		}

		public override void SetDefaults() 
		{
			item.damage = 75;
			item.ranged = true;
			item.width = 38;
			item.scale = 1.1f;
			item.maxStack = 1;
			item.height = 38;
			item.useTime = 5;
			item.useAnimation = 5;
			item.useStyle = 5;
			item.knockBack = 6.4f;
			item.value = 300000;
			item.rare = 8;
			item.crit = 10;
			item.UseSound = SoundID.Item12;
			item.shoot = mod.ProjectileType("MiniLaser");
			item.useAmmo = ModContent.ItemType<PowerCell>();
			item.shootSpeed = 4f;
			item.autoReuse = true;
			item.noMelee = true;
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.SDMG, 1);
			recipe.AddIngredient(ItemID.ChainGun, 1);
			recipe.AddIngredient(ItemID.LunarBar, 12);
			recipe.AddTile(TileID.LunarCraftingStation);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
		public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
		{
			float numberProjectiles = 1;
			float rotation = MathHelper.ToRadians(20);
			position += Vector2.Normalize(new Vector2(speedX, speedY)) * 20f;
			for (int i = 0; i < numberProjectiles; i++)
			{
				Vector2 pertubedSpeed = new Vector2(speedX, speedY).RotatedByRandom(MathHelper.ToRadians(22));
				Projectile.NewProjectile(position.X, position.Y, pertubedSpeed.X, pertubedSpeed.Y, type, damage, knockBack, player.whoAmI);
			}
			return false;
		}
		public override bool ConsumeAmmo(Player player)
		{
		return Main.rand.NextFloat() >= .66f;
		}
		public override Vector2? HoldoutOffset()
		{
			return new Vector2(-10, 0);
		}
	}
}