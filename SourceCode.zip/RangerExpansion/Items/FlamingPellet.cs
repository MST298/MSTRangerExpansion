using Terraria.ID;
using Terraria.ModLoader;

namespace RangerExpansion.Items
{
    public class FlamingPellet : ModItem
    {
        public override void SetDefaults()
        {
            item.damage = 2;
            item.ranged = true;
            item.width = 8;
            item.height = 8;
            item.maxStack = 999;
            item.consumable = true;
            item.knockBack = 0.5f;
            item.value = 1;
            item.rare = 2;
            item.shoot = mod.ProjectileType("Torchshot");
            item.shootSpeed = 2f;
            item.ammo = item.type;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Wood, 50);
            recipe.AddIngredient(ItemID.Torch, 1);
            recipe.AddTile(TileID.WorkBenches);
            recipe.SetResult(this, 50);
            recipe.AddRecipe();
        }
    }
}