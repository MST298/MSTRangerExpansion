using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace RangerExpansion.Items
{
	public class LaserPistol : ModItem
	{

		public override void SetDefaults() 
		{
			item.damage = 12;
			item.ranged = true;
			item.width = 38;
			item.maxStack = 1;
			item.height = 38;
			item.useTime = 16;
			item.useAnimation = 16;
			item.useStyle = 5;
			item.knockBack = 1f;
			item.value = 200000;
			item.rare = 8;
			item.crit = 0;
			item.UseSound = SoundID.Item12;
			item.shoot = mod.ProjectileType("MiniLaser");
			item.useAmmo = ModContent.ItemType<PowerCell>();
			item.shootSpeed = 4f;
			item.autoReuse = true;
			item.noMelee = true;
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.FlintlockPistol, 1);
			recipe.AddIngredient(mod, "PowerCell", 750);
			recipe.AddIngredient(ItemID.Sapphire, 2);
			recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
		public override Vector2? HoldoutOffset()
		{
			return new Vector2(0, 0);
		}
	}
}