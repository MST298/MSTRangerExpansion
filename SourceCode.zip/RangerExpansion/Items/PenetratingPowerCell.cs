using Terraria.ID;
using Terraria.ModLoader;

namespace RangerExpansion.Items
{
    public class PenetratingPowerCell : ModItem
    {
        public override void SetDefaults()
        {
            item.damage = 9;
            item.ranged = true;
            item.width = 8;
            item.height = 8;
            item.maxStack = 999;
            item.consumable = true;
            item.knockBack = 0.5f;
            item.value = 10;
            item.rare = 2;
            item.shoot = mod.ProjectileType("PenetratingLaser");
            item.shootSpeed = 14f;
            item.ammo = mod.ItemType("PowerCell");
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(mod, "PowerCell", 150);
            recipe.AddIngredient(ItemID.SoulofLight, 2);
            recipe.AddIngredient(ItemID.SoulofNight, 2);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this, 150);
            recipe.AddRecipe();
        }
    }
}