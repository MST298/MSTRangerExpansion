using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace RangerExpansion.Items
{
	public class FlamingMusket : ModItem
	{
		public override void SetStaticDefaults() 
		{
			// DisplayName.SetDefault("TestSword"); // By default, capitalization in classnames will add spaces to the display name. You can customize the display name here by uncommenting this line.
			Tooltip.SetDefault("'too lazy to sprite - MST'\n'Also uses lasers now?'");
		}

		public override void SetDefaults() 
		{
			item.damage = 38;
			item.ranged = true;
			item.width = 38;
			item.scale = 1f;
			item.maxStack = 1;
			item.height = 38;
			item.useTime = 22;
			item.useAnimation = 22;
			item.useStyle = 5;
			item.knockBack = 5.25f;
			item.value = 150000;
			item.rare = 8;
			item.crit = 7;
			item.UseSound = SoundID.Item12;
			item.shoot = mod.ProjectileType("MiniLaser");
			item.useAmmo = ModContent.ItemType<PowerCell>();
			item.shootSpeed = 4f;
			item.autoReuse = true;
			item.noMelee = true;
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.Musket, 1);
			recipe.AddIngredient(ItemID.HellstoneBar, 15);
			recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this);
			recipe.AddRecipe();

			ModRecipe recipe2 = new ModRecipe(mod);
			recipe2.AddIngredient(ItemID.TheUndertaker, 1);
			recipe2.AddIngredient(ItemID.HellstoneBar, 15);
			recipe2.AddTile(TileID.Anvils);
			recipe2.SetResult(this);
			recipe2.AddRecipe();
		}
		public override Vector2? HoldoutOffset()
		{
			return new Vector2(-2, 0);
		}
	}
}