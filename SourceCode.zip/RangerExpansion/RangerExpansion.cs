using Terraria.ModLoader;

namespace RangerExpansion
{
	public class RangerExpansion : Mod
	{
	}
}